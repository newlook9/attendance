package com.example.attendance;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;

public class MainActivity extends Activity {
  WebView w;
  ValueCallback<Uri[]> fcb;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
    w = new WebView(this);
    setContentView(w);
    final WebViewAssetLoader L = new WebViewAssetLoader.Builder()
      .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    w.addJavascriptInterface(new Object() {
      @JavascriptInterface public void save(String name, String text) {
        try {
          ContentValues c = new ContentValues();
          c.put(MediaStore.Downloads.DISPLAY_NAME, name);
          c.put(MediaStore.Downloads.MIME_TYPE, name.endsWith("json") ? "application/json" : "text/csv");
          Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c);
          OutputStream o = getContentResolver().openOutputStream(u);
          o.write(text.getBytes("UTF-8")); o.close();
          runOnUiThread(() -> Toast.makeText(MainActivity.this, "Downloads میں محفوظ: " + name, Toast.LENGTH_LONG).show());
        } catch (Exception e) {
          runOnUiThread(() -> Toast.makeText(MainActivity.this, "محفوظ نہیں ہو سکا", Toast.LENGTH_LONG).show());
        }
      }
    }, "Android");
    w.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        return L.shouldInterceptRequest(r.getUrl());
      }
    });
    w.setWebChromeClient(new WebChromeClient() {
      @Override public void onPermissionRequest(final PermissionRequest r) {
        runOnUiThread(() -> r.grant(r.getResources()));
      }
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
        fcb = cb; startActivityForResult(p.createIntent(), 2); return true;
      }
    });
    w.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }

  @Override protected void onActivityResult(int rq, int rs, Intent d) {
    if (rq == 2 && fcb != null) { fcb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d)); fcb = null; }
  }

  @Override public void onBackPressed() { /* کیوسک: غلطی سے باہر نہ نکلے */ }
}
